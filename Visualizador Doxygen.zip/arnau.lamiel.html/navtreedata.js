var NAVTREE =
[
  [ "arnau.lamiel", "index.html", [
    [ "Classes", "annotated.html", [
      [ "Llista de Classes", "annotated.html", "annotated_dup" ],
      [ "Índex de Classes", "classes.html", null ],
      [ "Membres de Classes", "functions.html", [
        [ "Tot", "functions.html", null ],
        [ "Funcions", "functions_func.html", null ]
      ] ]
    ] ],
    [ "Fitxers", null, [
      [ "Llista dels Fitxers", "files.html", "files" ],
      [ "Membres de Fitxers", "globals.html", [
        [ "Tot", "globals.html", null ],
        [ "Funcions", "globals_func.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_bin_tree_8hh.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';