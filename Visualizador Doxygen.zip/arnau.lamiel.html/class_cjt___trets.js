var class_cjt___trets =
[
    [ "afegir_noutret", "class_cjt___trets.html#a9806368dc3c92534f91fa0f4bbfd7bee", null ],
    [ "consultar_tret", "class_cjt___trets.html#aeb9c8adbdc7e1f3dfd1d7c184ff7d4af", null ],
    [ "reset", "class_cjt___trets.html#a25d223db9913ed0c029e9fefd254bb10", null ],
    [ "te_tret", "class_cjt___trets.html#a2b0845708a2ca836994c33a92891b1f3", null ],
    [ "treure_tret", "class_cjt___trets.html#ac09936c6788000daff442f288c97fce6", null ]
];