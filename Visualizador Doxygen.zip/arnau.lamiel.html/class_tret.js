var class_tret =
[
    [ "Tret", "class_tret.html#a3c892a10a6d209029a303b46b1deff17", null ],
    [ "Tret", "class_tret.html#a20ba4472a8dfa05a80212a66e94ede3f", null ],
    [ "actualitz_cromo", "class_tret.html#af54203d07ffe15aeba86e9f04e961c96", null ],
    [ "actualizar_par_cromo", "class_tret.html#a38670e26ef60d2b4f529a7c64da31316", null ],
    [ "afegir_id", "class_tret.html#ae043ddd56c38c9d019b69e3c624d5cfc", null ],
    [ "es_buit", "class_tret.html#a3a518cd3dee146cbf9c36b3a328cacd5", null ],
    [ "id_esta_tret", "class_tret.html#a99600936c453a404110f7b49cb4ed434", null ],
    [ "imprimir_tret", "class_tret.html#a06a2b469db444f7dbd3b9dc38eb7d578", null ],
    [ "treure_id", "class_tret.html#a1eb7e5cd916554ab47140d399a2f8648", null ]
];