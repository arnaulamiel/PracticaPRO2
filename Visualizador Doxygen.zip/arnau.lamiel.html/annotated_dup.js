var annotated_dup =
[
    [ "BinTree", "class_bin_tree.html", "class_bin_tree" ],
    [ "Cjt_Individus", "class_cjt___individus.html", "class_cjt___individus" ],
    [ "Cjt_PCr", "class_cjt___p_cr.html", "class_cjt___p_cr" ],
    [ "Cjt_Trets", "class_cjt___trets.html", "class_cjt___trets" ],
    [ "Individu", "class_individu.html", "class_individu" ],
    [ "Tret", "class_tret.html", "class_tret" ]
];