var class_cjt___individus =
[
    [ "Cjt_Individus", "class_cjt___individus.html#a832d4479dbccc8bcc5a089eb5ceb28f8", null ],
    [ "afegir_tret", "class_cjt___individus.html#aeb89df057985b2f33d5c31a56735b29e", null ],
    [ "consulta_individu", "class_cjt___individus.html#a625594f36a94aa12c7f7081d1d62f0ab", null ],
    [ "distribucio_arbre", "class_cjt___individus.html#ac044aa53d28cdf396869ce1991b0b103", null ],
    [ "escriure_arbre_distribucio", "class_cjt___individus.html#a5c8914de879df8acdceaad5a83713a66", null ],
    [ "llegir", "class_cjt___individus.html#aa23ed8ea718de53db62c746b9777b6b2", null ],
    [ "retorna_individu", "class_cjt___individus.html#a8b0eb2bf113cbb32b01e59123ed2a91b", null ],
    [ "treure_tret", "class_cjt___individus.html#aa8d69af0743f938ec7afb896e3c6eb16", null ]
];