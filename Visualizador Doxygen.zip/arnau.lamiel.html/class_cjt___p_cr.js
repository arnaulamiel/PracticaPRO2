var class_cjt___p_cr =
[
    [ "Cjt_PCr", "class_cjt___p_cr.html#a03964eb684975d8f4f7aca828b3679e8", null ],
    [ "imprimir", "class_cjt___p_cr.html#a1a46b50c2d1ee32144e1c9cb3103f3f2", null ],
    [ "interseccio", "class_cjt___p_cr.html#a870abfdb575d0a1ff2bc3bf35faf7e12", null ],
    [ "llegir_parells", "class_cjt___p_cr.html#a59afaeb6043fbd26a156ac4251e8c0e3", null ]
];