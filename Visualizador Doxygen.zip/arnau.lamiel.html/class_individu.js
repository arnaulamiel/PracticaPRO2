var class_individu =
[
    [ "Individu", "class_individu.html#ac35091404cfbf11946694806aefa9e7e", null ],
    [ "afegir_tret", "class_individu.html#a4d59ceca36c04dba1031ec2f846a800a", null ],
    [ "imprimir", "class_individu.html#a67f60deb723d2b133ab06ff850feb315", null ],
    [ "llegir_cromo", "class_individu.html#aeb858df9e8c669081c0068fc29595311", null ],
    [ "retorna_cromo", "class_individu.html#a02c5bf5dc73945776739f907ebab5ea9", null ],
    [ "te_tret", "class_individu.html#a5109e67e582e210b3a0b391a334056e9", null ],
    [ "treure_tret", "class_individu.html#ad0dcc9347b1477a1e9b2fc2acc35077b", null ]
];