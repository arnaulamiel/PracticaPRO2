var indexSectionsWithContent =
{
  0: "abcdeilmprtvw",
  1: "bcit",
  2: "bcipt",
  3: "abcdeilmrtvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Tot",
  1: "Classes",
  2: "Fitxers",
  3: "Funcions"
};

