var searchData=
[
  ['left',['left',['../class_bin_tree.html#a82108db4c1b08d1f111027788c196d4e',1,'BinTree']]],
  ['llegir',['llegir',['../class_cjt___individus.html#aa23ed8ea718de53db62c746b9777b6b2',1,'Cjt_Individus']]],
  ['llegir_5fcromo',['llegir_cromo',['../class_individu.html#aeb858df9e8c669081c0068fc29595311',1,'Individu']]],
  ['llegir_5fparells',['llegir_parells',['../class_cjt___p_cr.html#a59afaeb6043fbd26a156ac4251e8c0e3',1,'Cjt_PCr']]]
];
