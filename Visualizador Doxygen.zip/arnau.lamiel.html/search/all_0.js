var searchData=
[
  ['actualitz_5fcromo',['actualitz_cromo',['../class_tret.html#af54203d07ffe15aeba86e9f04e961c96',1,'Tret']]],
  ['actualizar_5fpar_5fcromo',['actualizar_par_cromo',['../class_tret.html#a38670e26ef60d2b4f529a7c64da31316',1,'Tret']]],
  ['afegir_5fid',['afegir_id',['../class_tret.html#ae043ddd56c38c9d019b69e3c624d5cfc',1,'Tret']]],
  ['afegir_5fnoutret',['afegir_noutret',['../class_cjt___trets.html#a9806368dc3c92534f91fa0f4bbfd7bee',1,'Cjt_Trets']]],
  ['afegir_5ftret',['afegir_tret',['../class_cjt___individus.html#aeb89df057985b2f33d5c31a56735b29e',1,'Cjt_Individus::afegir_tret()'],['../class_individu.html#a4d59ceca36c04dba1031ec2f846a800a',1,'Individu::afegir_tret()']]]
];
