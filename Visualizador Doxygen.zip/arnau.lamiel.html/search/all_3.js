var searchData=
[
  ['distribucio_5farbre',['distribucio_arbre',['../class_cjt___individus.html#ac044aa53d28cdf396869ce1991b0b103',1,'Cjt_Individus']]]
];
