var searchData=
[
  ['id_5festa_5ftret',['id_esta_tret',['../class_tret.html#a99600936c453a404110f7b49cb4ed434',1,'Tret']]],
  ['imprimir',['imprimir',['../class_cjt___p_cr.html#a1a46b50c2d1ee32144e1c9cb3103f3f2',1,'Cjt_PCr::imprimir()'],['../class_individu.html#a67f60deb723d2b133ab06ff850feb315',1,'Individu::imprimir()']]],
  ['imprimir_5ftret',['imprimir_tret',['../class_tret.html#a06a2b469db444f7dbd3b9dc38eb7d578',1,'Tret']]],
  ['individu',['Individu',['../class_individu.html#ac35091404cfbf11946694806aefa9e7e',1,'Individu']]],
  ['interseccio',['interseccio',['../class_cjt___p_cr.html#a870abfdb575d0a1ff2bc3bf35faf7e12',1,'Cjt_PCr']]]
];
